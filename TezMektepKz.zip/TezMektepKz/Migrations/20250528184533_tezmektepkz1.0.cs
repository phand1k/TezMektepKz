﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TezMektepKz.Migrations
{
    /// <inheritdoc />
    public partial class tezmektepkz10 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "197cbaf3-be34-4ba7-89d1-2f8bfc2d012a");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1c2d4181-d67f-41b8-a954-b20fab495b8c");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4ced307f-c98c-4f9f-a654-a13c02e8497d");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b7ae2062-e763-49bf-8e6b-ac6649b4e3ea");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f03b9074-3ea4-496c-bb00-8326aaad6e00");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "7584752e-7372-4af2-a6b2-f45f79c8bfb8", null, "Учитель", "УЧИТЕЛЬ" },
                    { "7bd0f547-89b6-4207-b62d-255577744cdd", null, "Директор", "ДИРЕКТОР" },
                    { "b259c952-cbf9-48de-b71b-07055b5dd497", null, "Админ", "АДМИН" },
                    { "b81ec80c-637b-4aef-b9b2-144bb1380776", null, "Ученик", "УЧЕНИК" },
                    { "e7d657bf-955a-4a0e-b8c8-f228a01df910", null, "Кассир", "КАССИР" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7584752e-7372-4af2-a6b2-f45f79c8bfb8");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7bd0f547-89b6-4207-b62d-255577744cdd");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b259c952-cbf9-48de-b71b-07055b5dd497");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b81ec80c-637b-4aef-b9b2-144bb1380776");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e7d657bf-955a-4a0e-b8c8-f228a01df910");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "197cbaf3-be34-4ba7-89d1-2f8bfc2d012a", null, "Учитель", "УЧИТЕЛЬ" },
                    { "1c2d4181-d67f-41b8-a954-b20fab495b8c", null, "Директор", "ДИРЕКТОР" },
                    { "4ced307f-c98c-4f9f-a654-a13c02e8497d", null, "Кассир", "КАССИР" },
                    { "b7ae2062-e763-49bf-8e6b-ac6649b4e3ea", null, "Ученик", "УЧЕНИК" },
                    { "f03b9074-3ea4-496c-bb00-8326aaad6e00", null, "Админ", "АДМИН" }
                });
        }
    }
}
