﻿using Microsoft.AspNetCore.Mvc;
using TezMektepKz.Models.Identity;
using TezMektepKz.Services.Interfaces;

namespace TezMektepKz.Controllers
{
    public class OrganizationController : Controller
    {
        private readonly IOrganizationService organizationService;
        public OrganizationController(IOrganizationService organizationService)
        {
            this.organizationService = organizationService;
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
