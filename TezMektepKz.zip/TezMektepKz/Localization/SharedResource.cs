﻿namespace TezMektepKz.Localization
{
    public class SharedResource
    {
    }
}
