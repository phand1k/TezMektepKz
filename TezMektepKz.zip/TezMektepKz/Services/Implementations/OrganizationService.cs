﻿using TezMektepKz.Models.Identity;
using TezMektepKz.Repositories.Interfaces;
using TezMektepKz.Services.Interfaces;

namespace TezMektepKz.Services.Implementations
{
    public class OrganizationService : IOrganizationService
    {
        private readonly IOrganizationRepository organizationRepository;
        public OrganizationService(IOrganizationRepository organizationRepository)
        {
            this.organizationRepository = organizationRepository;
        }
        public Task<Organization> AddAsync(Organization organization)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<Organization> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<Organization> GetByNumberAsync(string number)
        {
            return await organizationRepository.GetByNumberAsync(number);
        }

        public Task UpdateAsync(Organization organization)
        {
            throw new NotImplementedException();
        }
    }
}
