﻿namespace TezMektepKz.Models.Identity.Role
{
    public class UserRoles
    {
        public string RoleName { get; set; }
    }
}
